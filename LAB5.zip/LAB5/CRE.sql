USE master;
GO
DECLARE @kill varchar(8000); SET @kill = '';
SELECT @kill = @kill + 'kill ' + CONVERT(varchar(5), spid) + ';'
FROM master..sysprocesses
WHERE dbid = db_id('LAB5')
EXEC(@kill);
GO
IF EXISTS(select * from sys.databases where name='LAB5')
DROP DATABASE LAB5
GO
CREATE DATABASE LAB5
GO
USE LAB5
GO
CREATE TABLE SALLE (
  id        int   NOT NULL   IDENTITY (0,1),
  libelle   char  NOT NULL ,
  machine   int   NOT NULL ,
  capacite  int   NOT NULL ,
  PRIMARY KEY (id)
)
GO
CREATE TABLE MACHINE (
  id           int       NOT NULL   IDENTITY (0,1),
  libelle      char(50)  NOT NULL ,
  processeur   char(50)  NOT NULL ,
  memoire      int       NOT NULL CHECK (memoire > 0),
  disque       int       NOT NULL CHECK (disque > 0),
  taille_ecran int       NOT NULL CHECK (taille_ecran > 0),
  PRIMARY KEY (id),
)
GO
CREATE TABLE COURS (
  id           int       NOT NULL     IDENTITY (0,1),
  code         char(10)  NULL ,
  titre        char(50)  NULL ,
  duree        tinyint   NULL ,
  programme    xml       NULL ,
  PRIMARY KEY (id)
)
GO
CREATE TABLE  COURS_MACHINE (
  id          int   NOT NULL      IDENTITY (0,1),
  cours       int   NOT NULL ,
  salle       int   NOT NULL ,
  PRIMARY KEY (id)
)
GO
CREATE TABLE FORMATION (
  id          int   NOT NULL ,
  libelle     char      NULL ,
  cours       int   NOT NULL ,
  salle       int   NOT NULL ,
  debut       date  NOT NULL ,
  fin         date  NOT NULL ,
  PRIMARY KEY (id)
)
GO
USE master
GO
IF EXISTS(select * from sys.databases where name='GestSalles')
DROP DATABASE GestSalles
GO
USE master;
GO
CREATE DATABASE GestSalles
ON
( NAME = gestsalles_dat,
    --CHANGE THE PATH FOR WINDOW THIS FOLDER IS ON DOCKER WITH PERM 777--
    FILENAME = '/LAB/LAB5/gestsalles_ppal.mdf',
    SIZE = 20,
    MAXSIZE = 50,
    FILEGROWTH = 5 )
LOG ON
( NAME = gestsalles_log,
    FILENAME = '/LAB/LAB5/gestsalles_log.ldf',
    SIZE = 5MB,
    MAXSIZE = 20MB,
    FILEGROWTH = 2MB );
GO

